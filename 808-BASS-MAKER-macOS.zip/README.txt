808 BASS MAKER for macOS (Apple Silicon + Intel)

1. Copy "808 BASS MAKER.vst3"      to  /Library/Audio/Plug-Ins/VST3/
   Copy "808 BASS MAKER.component" to  /Library/Audio/Plug-Ins/Components/
2. Open Terminal and run (removes the "downloaded from internet" block):
   sudo xattr -dr com.apple.quarantine "/Library/Audio/Plug-Ins/VST3/808 BASS MAKER.vst3" "/Library/Audio/Plug-Ins/Components/808 BASS MAKER.component"
3. Rescan plugins in your DAW.
